# SieveOfEratostenes
A simple java application which prints out prime numbers up to the point which is passed by a parameter
